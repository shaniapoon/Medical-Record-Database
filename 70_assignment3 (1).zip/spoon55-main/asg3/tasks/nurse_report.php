<?php
include 'dbconnect.php';

// Fetch nurse data from the database
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nurseID = $_POST['nurseID'];

    // Get patients assigned to the selected nurse
    $stmt = $conn->prepare("SELECT patient.firstName AS patientFirstName, patient.lastName AS patientLastName, patient.ohip, patient.height, patient.weight, patient.treatsdocid 
                             FROM patient
                             JOIN workingfor ON patient.treatsdocid = workingfor.docid
                             JOIN nurse ON nurse.nurseid = workingfor.nurseid
                             WHERE nurse.nurseid = ?");
    if ($stmt === false) {
        die('Error preparing SQL query: ' . $conn->error);
    }

    // Bind parameters for the query
    $stmt->bind_param("s", $nurseID);  // "s" means the parameter is a string
    $stmt->execute();
    $patientsResult = $stmt->get_result();
    $patients = $patientsResult->fetch_all(MYSQLI_ASSOC);

    // Fetch nurse details for display
    $nurseStmt = $conn->prepare("SELECT firstName, lastName, reporttonurseid FROM nurse WHERE nurseid = ?");
    if ($nurseStmt === false) {
        die('Error preparing nurse query: ' . $conn->error);
    }
    $nurseStmt->bind_param("s", $nurseID);
    $nurseStmt->execute();
    $nurseResult = $nurseStmt->get_result();
    $nurse = $nurseResult->fetch_assoc();  // Fetch single row as an associative array

    // Check if the nurse has a supervisor
    if ($nurse['reporttonurseid']) {
        $supervisorStmt = $conn->prepare("SELECT firstName, lastName FROM nurse WHERE nurseid = ?");
        if ($supervisorStmt === false) {
            die('Error preparing supervisor query: ' . $conn->error);
        }
        $supervisorStmt->bind_param("s", $nurse['reporttonurseid']);
        $supervisorStmt->execute();
        $supervisorResult = $supervisorStmt->get_result();
        $supervisor = $supervisorResult->fetch_assoc();  // Fetch supervisor details if available
    } else {
        $supervisor = null;  // If no supervisor, set as null
    }
}

// Fetch all nurses for selection
$nursesStmt = $conn->prepare("SELECT nurseid, firstName, lastName FROM nurse");
if ($nursesStmt === false) {
    die('Error preparing nurses query: ' . $conn->error);
}
$nursesStmt->execute();
$nursesResult = $nursesStmt->get_result();
$nurses = $nursesResult->fetch_all(MYSQLI_ASSOC);  // Fetch all nurses as an associative array
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Nurse Report</title>
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>
    <h1>Generate Nurse Report</h1>

    <form method="post">
        <label for="nurseID">Select Nurse:</label>
        <select name="nurseID" required>
            <?php foreach ($nurses as $nurseOption): ?>
                <option value="<?= $nurseOption['nurseid'] ?>"><?= $nurseOption['firstName'] ?> <?= $nurseOption['lastName'] ?></option>
            <?php endforeach; ?>
        </select><br>
        <button type="submit">Generate Report</button>
    </form>

    <?php if (isset($patients)): ?>
        <h2>Patients Assigned to <?= $nurse['firstName'] . ' ' . $nurse['lastName'] ?></h2>
        <table border="1">
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>OHIP</th>
                    <th>Height (cm)</th>
                    <th>Weight (kg)</th>
                    <th>Assigned Doctor</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($patients as $patient): ?>
                    <tr>
                        <td><?= $patient['patientFirstName'] . ' ' . $patient['patientLastName'] ?></td>
                        <td><?= $patient['ohip'] ?></td>
                        <td><?= $patient['height'] ?></td>
                        <td><?= $patient['weight'] ?></td>
                        <td>
                            <?php
                            // Fetch doctor's name
                            $doctorStmt = $conn->prepare("SELECT firstName, lastName FROM doctor WHERE docid = ?");
                            if ($doctorStmt === false) {
                                die('Error preparing doctor query: ' . $conn->error);
                            }
                            $doctorStmt->bind_param("s", $patient['treatsdocid']);
                            $doctorStmt->execute();
                            $doctorResult = $doctorStmt->get_result();
                            $doctor = $doctorResult->fetch_assoc();
                            echo $doctor['firstName'] . ' ' . $doctor['lastName'];
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <?php if ($supervisor): ?>
            <h3>Supervisor: <?= $supervisor['firstName'] . ' ' . $supervisor['lastName'] ?></h3>
        <?php else: ?>
            <h3>No supervisor assigned</h3>
        <?php endif; ?>
    <?php endif; ?>

</body>
</html>
