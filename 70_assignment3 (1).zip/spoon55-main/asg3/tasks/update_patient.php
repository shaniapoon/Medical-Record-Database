<?php
include 'dbconnect.php';

$success = $error = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ohip = $_POST['ohip'];
    $weight = $_POST['weight'];
    $unit = $_POST['unit'];

    // Validate the input weight
    if (!is_numeric($weight) || $weight <= 0) {
        $error = "Error: Weight must be a positive number.";
    } else {
        // Convert weight to kilograms if entered in pounds
        if ($unit === 'lbs') {
            $weight = round($weight * 0.453592, 2); // Round to 2 decimal places
        } else {
            $weight = round($weight, 2); // Round kilograms to 2 decimal places
        }

        // Check if the OHIP number exists
        $checkStmt = $conn->prepare("SELECT * FROM patient WHERE ohip = ?");
        $checkStmt->bind_param("s", $ohip);
        $checkStmt->execute();
        $result = $checkStmt->get_result();

        if ($result->num_rows > 0) {
            // Update the patient's weight
            $updateStmt = $conn->prepare("UPDATE patient SET weight = ? WHERE ohip = ?");
            $updateStmt->bind_param("ds", $weight, $ohip);
            if ($updateStmt->execute()) {
                $success = "Patient weight updated successfully!";
            } else {
                $error = "Error: Could not update the weight. Please try again.";
            }
            $updateStmt->close();
        } else {
            $error = "Error: Patient with OHIP number $ohip does not exist.";
        }
        $checkStmt->close();
    }
}

// Fetch patients
$patientsStmt = $conn->prepare("SELECT ohip, firstname, lastname FROM patient");
$patientsStmt->execute();
$patientsResult = $patientsStmt->get_result();
$patients = [];
while ($row = $patientsResult->fetch_assoc()) {
    $patients[] = $row;
}
$patientsStmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Patient Weight</title>
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>
    <h1>Update Patient Weight</h1>

    <?php if ($success): ?>
        <p style="color: green;"><?= $success ?></p>
    <?php elseif ($error): ?>
        <p style="color: red;"><?= $error ?></p>
    <?php endif; ?>

    <form method="post">
        <label for="ohip">Select Patient (OHIP Number):</label>
        <select name="ohip" required>
            <?php foreach ($patients as $patient): ?>
                <option value="<?= $patient['ohip'] ?>"><?= $patient['firstname'] . ' ' . $patient['lastname'] ?> (<?= $patient['ohip'] ?>)</option>
            <?php endforeach; ?>
        </select><br>

        <label for="weight">New Weight:</label>
        <input type="number" step="0.01" name="weight" required>
        <select name="unit">
            <option value="kg">Kilograms</option>
            <option value="lbs">Pounds</option>
        </select><br>

        <button type="submit">Update Weight</button>
    </form>
</body>
</html>
