<?php
include 'dbconnect.php'; 

// Fetch doctors with no patients
$query = "
    SELECT docid, firstname, lastname 
    FROM doctor 
    WHERE docid NOT IN (SELECT DISTINCT treatsdocid FROM patient)
";

// Prepare and execute the query
$result = $conn->query($query);

// Check if the query executed successfully
if (!$result) {
    $error = "An error occurred while fetching data. Please try again later.";
    error_log("Database error: " . $conn->error);
} else {
    $doctors = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctors with No Patients</title>
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>
    <h1>Doctors with No Patients Assigned</h1>
    <ul>
        <?php if (empty($doctors)): ?>
            <p>No doctors without patients.</p>
        <?php else: ?>
            <?php foreach ($doctors as $doctor): ?>
                <li><?= htmlspecialchars($doctor['firstname'] . ' ' . $doctor['lastname'] . ' (ID: ' . $doctor['docid'] . ')') ?></li>
            <?php endforeach; ?>
        <?php endif; ?>
    </ul>
</body>
</html>
