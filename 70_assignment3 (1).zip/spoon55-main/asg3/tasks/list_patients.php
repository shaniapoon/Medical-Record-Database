<?php
// Include the database connection
include('dbconnect.php');

// Default sorting column and direction
$sort_by = 'lastname'; // Default sort by lastname
$order = 'ASC'; // Default order is ascending

// Check if form values are set (sorting and order direction)
if (isset($_POST['sort_by'])) {
    $sort_by = $_POST['sort_by'];
}
if (isset($_POST['order'])) {
    $order = $_POST['order'];
}

// Query to get all patients, ordering by user input
$query = "SELECT p.ohip, p.firstname, p.lastname, p.weight, p.height, p.birthdate, p.treatsdocid, 
                 d.firstname AS doctor_firstname, d.lastname AS doctor_lastname
          FROM patient p 
          LEFT JOIN doctor d ON p.treatsdocid = d.docid
          ORDER BY $sort_by $order";

// Execute query
$result = mysqli_query($conn, $query);

// Check if the query executed successfully
if (!$result) {
    // If there's an error, display it and stop the script
    die('Error executing query: ' . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient List</title>
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>

    <h1>Patient List</h1>

    <!-- Form for sorting -->
    <form method="POST" action="list_patients.php">
        <label>Sort by:</label>
        <input type="radio" name="sort_by" value="firstname" <?php if ($sort_by == 'firstname') echo 'checked'; ?>> First Name
        <input type="radio" name="sort_by" value="lastname" <?php if ($sort_by == 'lastname') echo 'checked'; ?>> Last Name
        <br>
        <label>Order:</label>
        <input type="radio" name="order" value="ASC" <?php if ($order == 'ASC') echo 'checked'; ?>> Ascending
        <input type="radio" name="order" value="DESC" <?php if ($order == 'DESC') echo 'checked'; ?>> Descending
        <br>
        <input type="submit" value="Sort">
    </form>

    <h2>Patients</h2>
    <table border="1">
        <thead>
            <tr>
                <th>OHIP</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Weight</th>
                <th>Height</th>
                <th>Birthdate</th>
                <th>Doctor</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Function to convert weight from kg to pounds
            function convertWeightToPounds($weightInKg) {
                return round($weightInKg * 2.20462, 2);
            }

            // Function to convert height from meters to feet and inches
            function convertHeightToFeetInches($heightInM) {
                $heightInFeet = $heightInM * 3.28084; // Convert to feet
                $feet = floor($heightInFeet); // Get the whole number of feet
                $inches = round(($heightInFeet - $feet) * 12); // Convert the decimal part to inches
                return "$feet feet $inches inches";
            }

            // Display the patient data
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['ohip'] . "</td>";
                echo "<td>" . $row['firstname'] . "</td>";
                echo "<td>" . $row['lastname'] . "</td>";
                echo "<td>" . $row['weight'] . " kg (" . convertWeightToPounds($row['weight']) . " lbs)</td>";
                echo "<td>" . $row['height'] . " m (" . convertHeightToFeetInches($row['height']) . ")</td>";
                echo "<td>" . $row['birthdate'] . "</td>";
                echo "<td>" . $row['doctor_firstname'] . " " . $row['doctor_lastname'] . "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>

</body>
</html>

