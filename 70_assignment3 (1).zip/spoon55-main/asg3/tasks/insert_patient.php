<?php
include 'dbconnect.php';
$error = ""; // Initialize error message
$success = ""; // Initialize success message

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $ohip = $_POST['ohip'];
    $height = $_POST['height'];
    $weight = $_POST['weight'];
    $doctorID = $_POST['doctorID'];
    $error = $success = ""; // Initialize messages

    // Check if OHIP already exists
    $checkStmt = $conn->prepare("SELECT * FROM patient WHERE ohip = ?");
    $checkStmt->bind_param("s", $ohip);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows > 0) {
        $error = "Error: A patient with this OHIP number already exists.";
    } else {
        // Insert the new patient into the database
        $insertStmt = $conn->prepare("INSERT INTO patient (firstname, lastname, ohip, height, weight, treatsdocid) VALUES (?, ?, ?, ?, ?, ?)");
        $insertStmt->bind_param("sssdds", $firstName, $lastName, $ohip, $height, $weight, $doctorID);
        if ($insertStmt->execute()) {
            $success = "Patient added successfully!";
        } else {
            $error = "Error: Could not add the patient. Please try again." . $insertStmt->error;
        }
        $insertStmt->close(); // Close only if prepared
    }
    $checkStmt->close(); // Close after check
}

// Fetch available doctors
$doctorsStmt = $conn->prepare("SELECT docid, firstname, lastname FROM doctor");
$doctorsStmt->execute();
$doctorsResult = $doctorsStmt->get_result();
$doctors = [];
while ($row = $doctorsResult->fetch_assoc()) {
    $doctors[] = $row;
}
$doctorsStmt->close();

// Close the database connection after processing is complete
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Patient</title>
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>
    <h1>Add New Patient</h1>
    <?php if ($error): ?>
        <p style="color: red;"><?= htmlspecialchars($error) ?></p>
    <?php elseif ($success): ?>
        <p style="color: green;"><?= htmlspecialchars($success) ?></p>
    <?php endif; ?>

    <form method="post">
        <label for="firstName">First Name:</label>
        <input type="text" name="firstName" required><br>
        <label for="lastName">Last Name:</label>
        <input type="text" name="lastName" required><br>
        <label for="ohip">OHIP Number:</label>
        <input type="text" name="ohip" required><br>
        <label for="height">Height (cm):</label>
        <input type="number" step="0.01" name="height" required><br>
        <label for="weight">Weight (kg):</label>
        <input type="number" step="0.01" name="weight" required><br>
        <label for="doctorID">Assign Doctor:</label>
        <select name="doctorID" required>
            <?php foreach ($doctors as $doctor): ?>
                <option value="<?= htmlspecialchars($doctor['docid']) ?>">
                    <?= htmlspecialchars($doctor['firstname'] . ' ' . $doctor['lastname']) ?>
                </option>
            <?php endforeach; ?>
        </select><br>
        <button type="submit">Add Patient</button>
    </form>

    <!-- Back button to navigate to the main menu -->
    <br>
    <a href="../mainmenu.php">
        <button type="button" style="padding: 10px 20px; background-color: #4CAF50; color: white; border: none; cursor: pointer;">
        Back to Main Menu
        </button>
    </a>


</body>
</html>
