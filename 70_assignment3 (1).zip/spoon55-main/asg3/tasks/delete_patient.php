<?php
include 'dbconnect.php';

$success = $error = "";

// Handle deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ohip = $_POST['ohip'];

    // Check if the OHIP number exists
    $checkStmt = $conn->prepare("SELECT * FROM patient WHERE ohip = ?");
    $checkStmt->bind_param("s", $ohip);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows > 0) {
        // Confirm deletion
        if (isset($_POST['confirm_delete'])) {
            $deleteStmt = $conn->prepare("DELETE FROM patient WHERE ohip = ?");
            $deleteStmt->bind_param("s", $ohip);
            if ($deleteStmt->execute()) {
                $success = "Patient deleted successfully!";
            } else {
                $error = "Error: Could not delete the patient. Please try again.";
            }
            $deleteStmt->close();
        } else {
            $error = "Deletion cancelled.";
        }
    } else {
        $error = "Error: Patient with OHIP number $ohip does not exist.";
    }
    $checkStmt->close();
}

// Fetch patients
$patientsStmt = $conn->prepare("SELECT ohip, firstname, lastname FROM patient");
$patientsStmt->execute();
$patientsResult = $patientsStmt->get_result();
$patients = [];
while ($row = $patientsResult->fetch_assoc()) {
    $patients[] = $row;
}
$patientsStmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Patient</title>
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>
    <h1>Delete Patient</h1>

    <?php if ($success): ?>
        <p style="color: green;"><?= $success ?></p>
    <?php elseif ($error): ?>
        <p style="color: red;"><?= $error ?></p>
    <?php endif; ?>

    <form method="post">
        <label for="ohip">Enter OHIP Number to Delete:</label>
        <input type="text" name="ohip" required><br>
        <input type="checkbox" name="confirm_delete" required>
        <label for="confirm_delete">Are you sure you want to delete this patient?</label><br>
        <button type="submit">Delete Patient</button>
    </form>

    <h2>Or Select a Patient to Delete:</h2>
    <form method="post">
        <select name="ohip" required>
            <?php foreach ($patients as $patient): ?>
                <option value="<?= $patient['ohip'] ?>"><?= $patient['firstname'] . ' ' . $patient['lastname'] ?> (<?= $patient['ohip'] ?>)</option>
            <?php endforeach; ?>
        </select><br>
        <input type="checkbox" name="confirm_delete" required>
        <label for="confirm_delete">Are you sure you want to delete this patient?</label><br>
        <button type="submit">Delete Selected Patient</button>
    </form>


</body>
</html>
