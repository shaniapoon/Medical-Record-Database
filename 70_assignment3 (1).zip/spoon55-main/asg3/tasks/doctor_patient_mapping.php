<?php
include 'dbconnect.php'; 

// Prepare the SQL query to fetch doctors and their patients
$sql = "
    SELECT 
        doctor.firstname AS docFirstName, 
        doctor.lastname AS docLastName, 
        patient.firstname AS patientFirstName, 
        patient.lastname AS patientLastName
    FROM doctor
    LEFT JOIN patient ON doctor.docid = patient.treatsdocid
";

// Attempt to prepare the query
$stmt = $conn->prepare($sql);

// Check if the preparation was successful
if (!$stmt) {
    $error = "An error occurred while preparing the query.";
    error_log("Database error: " . $conn->error);
} else {
    $stmt->execute();
    $doctorPatientMapping = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor-Patient Mapping</title>
    <link rel="stylesheet" href="../styles/styles.css">
</head>
<body>
    <h1>Doctor-Patient Mapping</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Doctor</th>
                <th>Patient</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($doctorPatientMapping as $entry): ?>
                <tr>
                    <td><?= htmlspecialchars($entry['docFirstName'] . ' ' . $entry['docLastName']) ?></td>
                    <td><?= htmlspecialchars($entry['patientFirstName'] . ' ' . $entry['patientLastName']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
