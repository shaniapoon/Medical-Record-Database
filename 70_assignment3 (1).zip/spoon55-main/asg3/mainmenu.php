<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Main Menu</title>
    <link rel="stylesheet" href="styles/styles.css">
</head>
<body>
    <h1>Main Menu</h1>
    <ul>
        <li><a href="tasks/list_patients.php">List Patients</a></li>
        <li><a href="tasks/insert_patient.php">Add New Patient</a></li>
        <li><a href="tasks/delete_patient.php">Delete Patient</a></li>
        <li><a href="tasks/update_patient.php">Update Patient Weight</a></li>
        <li><a href="tasks/list_unassigned_doctors.php">Doctors with No Patients</a></li>
        <li><a href="tasks/doctor_patient_mapping.php">Doctor-Patient Mapping</a></li>
        <li><a href="tasks/nurse_report.php">Nurse Report</a></li>
    </ul>

</body>
</html>

